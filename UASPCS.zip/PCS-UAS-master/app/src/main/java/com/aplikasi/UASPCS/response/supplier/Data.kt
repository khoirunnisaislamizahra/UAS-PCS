package com.aplikasi.UASPCS.response.supplier

data class Data(
    val produk: List<Supplier>
)