package com.aplikasi.UASPCS.response.itemTransaksi

data class Data(
    val item_transaksi: ItemTransaksi
)